from __future__ import print_function

import json
import requests
import boto3
import logging

ka = boto3.client('kinesisanalytics')

log = logging.getLogger()
log.setLevel(logging.INFO)

def sendResponse(event, responseStatus, resourceId, reason):
    responseBody = {'Status': responseStatus,
                    'PhysicalResourceId': resourceId,
                    'LogicalResourceId': event['LogicalResourceId'],
                    'StackId': event['StackId'],
                    'RequestId': event['RequestId'],
                    }
    if responseStatus == "FAILED":
        responseBody['Reason'] = reason
    log.info('RESPONSE BODY:n' + json.dumps(responseBody))
    try:
        requests.put(event['ResponseURL'], data=json.dumps(responseBody))
        return
    except Exception as e:
        log.error(e)
        raise

def addOutput(event, context):
    log.info('Attempting to add output to application')
    try:
        # Get function arguments
        FunctionName = event['ResourceProperties']['FunctionName']
        Region = event['ResourceProperties']['Region']
        appName = event['ResourceProperties']['AppName']
        Destination = event['ResourceProperties']['Destination']
        destStreamName = event['ResourceProperties']['DestinationStreamName']
        outputRoleARN = event['ResourceProperties']['OutputRole']
        if 'RedshiftDest' in event['ResourceProperties']:
            RedshiftDest = event['ResourceProperties']['RedshiftDest']
            outputARN = RedshiftDest
        if 'S3Dest' in event['ResourceProperties']:
            S3Dest = event['ResourceProperties']['S3Dest']
            outputARN = S3Dest
        if 'ElasticsearchDest' in event['ResourceProperties']:
            ElasticsearchDest = event['ResourceProperties']['ElasticsearchDest']
            outputARN = ElasticsearchDest
        if 'StreamDest' in event['ResourceProperties']:
            StreamDest = event['ResourceProperties']['StreamDest']
            outputARN = StreamDest
        
        # Get application details
        log.info('getting details for ' + appName)
        appDetails = ka.describe_application(ApplicationName=appName)
        appVersionId = appDetails['ApplicationDetail']['ApplicationVersionId']
        inputFormat = appDetails['ApplicationDetail']['InputDescriptions'][0]['InputSchema']['RecordFormat']['RecordFormatType']

        # Set the output record format
        log.info('setting record format')
        if Destination == "Amazon Redshift":
            outputrecordformat = 'CSV'
        elif Destination == "Amazon ElasticSearch Service":
            outputrecordformat = 'JSON'
        else:
            outputrecordformat = inputFormat
        log.info('record format set to '+ outputrecordformat)
        
        # Create Kinesis Analytics output based on the external destination selected by the user in the CloudFormation template
        if Destination == "Amazon Kinesis Stream":
            outputType = 'KinesisStreamsOutput'
        else:
            outputType = 'KinesisFirehoseOutput'
        log.info('adding output configuration for '+ outputType)
        newOutput = {'Name': destStreamName, outputType: {'ResourceARN': outputARN, 'RoleARN': outputRoleARN},"DestinationSchema": {"RecordFormatType":outputrecordformat}}
        
        # Add the application output
        log.info('adding output to application')
        response = ka.add_application_output(
            ApplicationName=appName,
            CurrentApplicationVersionId=appVersionId,
            Output= newOutput
        )

        # If Amazon Kinesis Analytics API returns a non-200 response, script fails
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            physicalResource = 'ApplicationOutput:' + appName + '/' + destStreamName
            responseStatus = 'SUCCESS'
            log.info('Successfully added output to application')
            sendResponse(event, responseStatus, physicalResource, None)
        else:
            responseStatus = "FAILED"
            log.error('Failed to add output to application')
            errorlogs = 'https://' + Region + '.console.aws.amazon.com/cloudwatch/home?region=' + Region + '#logEventViewer:group=/aws/lambda/' + FunctionName
            reason = 'See details in Amazon CloudWatch: '+ errorlogs
            sendResponse(event, responseStatus, "", reason)
    
    except Exception as e:
        responseStatus = "FAILED"
        log.error(e)
        errorlogs = 'https://' + Region + '.console.aws.amazon.com/cloudwatch/home?region=' + Region + '#logEventViewer:group=/aws/lambda/' + FunctionName
        reason = 'See details in Amazon CloudWatch: '+ errorlogs
        sendResponse(event, responseStatus, "", reason)

def deleteOutput(event, context):
    log.info('Attempting to delete output from Kinesis Analytics application')
    if event['PhysicalResourceId'].startswith('ApplicationOutput:'):
        try:
            log.info('getting application name and destination stream name')
            application = (event['PhysicalResourceId'].split(":")[1]).split("/")[0]
            destStream = (event['PhysicalResourceId'].split(":")[1]).split("/")[1]

            # Get output ID of the destination stream to be deleted
            deleteAppDetails = ka.describe_application(ApplicationName=application)
            appVersionId = deleteAppDetails['ApplicationDetail']['ApplicationVersionId']
            for i in deleteAppDetails['ApplicationDetail']['OutputDescriptions']:
                if i['Name'] == destStream:
                    ouputId = i['OutputId']
            
            # Delete the output
            log.info('deleting '+ destStream)
            deleteResponse = ka.delete_application_output(
                ApplicationName=application,
                CurrentApplicationVersionId=appVersionId,
                OutputId=ouputId
            )
            # If Amazon Kinesis Analytics API returns a non-200 response, script fails
            if deleteResponse['ResponseMetadata']['HTTPStatusCode'] == 200:
                responseStatus = 'SUCCESS'
                log.info('Successfully deleted application output')
                sendResponse(event, responseStatus, event['PhysicalResourceId'], None)
            else: 
                responseStatus = "FAILED"
                log.error('Failed to delete application output')
                errorlogs = 'https://' + Region + '.console.aws.amazon.com/cloudwatch/home?region=' + Region + '#logEventViewer:group=/aws/lambda/' + FunctionName
                reason = 'See details in Amazon CloudWatch: '+ errorlogs
                sendResponse(event, responseStatus, event['PhysicalResourceId'], reason)

        except Exception as e:
            responseStatus = "FAILED"
            log.error(e)
            errorlogs = 'https://' + Region + '.console.aws.amazon.com/cloudwatch/home?region=' + Region + '#logEventViewer:group=/aws/lambda/' + FunctionName
            reason = 'See details in Amazon CloudWatch: '+ errorlogs
            sendResponse(event, responseStatus, event['PhysicalResourceId'], reason)
    else:
        responseStatus = 'SUCCESS'
        log.info('this script did not create any application output, nothing to delete')
        sendResponse(event, responseStatus, event['PhysicalResourceId'], None)

def lambda_handler(event, context):
    if event['RequestType'] == 'Delete':
        deleteOutput(event,context)
    if event['RequestType'] == 'Create':
        addOutput(event,context)